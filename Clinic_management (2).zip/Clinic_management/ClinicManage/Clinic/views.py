from django.shortcuts import render,redirect,HttpResponseRedirect
from django.contrib.auth.models import User
from .models import AddP, AddDoctor,Appointment,Payment, Log_in_id
from django.contrib.auth import authenticate, login
# from django.contrib.auth import login as auth_login
from datetime import datetime
from django.urls import reverse
from django.contrib import messages
# from django.http import 


# Create your views here.

def Dashboard(request):
    if request.method == 'POST':
        username = request.POST['Username']
        password = request.POST['Password']
        data = Log_in_id.objects.get(id=1)
        uname = data.Username
        pw = data.Password
        if username == uname and password == pw:
            return render(request,"Dashboard.html")
        else:
            return render(request, "Loginpage.html")
    else:
        return render(request, "Loginpage.html")

    
# def Loginpage(request):
#     if request.method == 'POST':
#         username = request.POST['loginusername']
#         password = request.POST['loginpassword']
#         User = authenticate(request, loginusername=username, loginpassword=password)
#         if User is not None:
#             login(request, User)
#             return render(request,'Dashboard.html')  # Redirect to the dashboard page
#         else:
#             messages.error(request,("Error...try again later"))
#             return redirect(Loginpage)
#             # return HttpResponse("Method not allowed")
#     return render(request, 'Loginpage.html')
#    return render(request,'Login.html')


def Loginpage(request):
    return render(request, "Loginpage.html")


#------------------------------------------PATIENT-------------------------------------------------------


   

def AddPatient(request):
    if request.method == 'POST':
        title = request.POST.get('title')
        name = request.POST.get('name')
        gender = request.POST.get('gender')
        date_of_birth = request.POST.get('date_of_birth')
        age = request.POST.get('age')
        address = request.POST.get('address')
        contact_no = request.POST.get('contact_no')
        blood_group = request.POST.get('blood_group')
        systolic_bp = request.POST.get('systolic_bp')
        diastolic_bp = request.POST.get('diastolic_bp')
        temperature = request.POST.get('temperature')
        weight = request.POST.get('weight')
        respiratory_rate = request.POST.get('respiratory_rate')
        heart_rate = request.POST.get('heart_rate')
        bmi = request.POST.get('bmi')
        blood_sugar_f = request.POST.get('blood_sugar_f')
        blood_sugar_r = request.POST.get('blood_sugar_r')
        spo2 = request.POST.get('spo2')

        # Save the form data to the database using the HealthRecord model
        new= AddP(
            title=title,
            name=name,
            gender=gender,
            date_of_birth=date_of_birth,
            age=age,
            address=address,
            contact_no=contact_no,
            blood_group=blood_group,
            systolic_bp=systolic_bp,
            diastolic_bp=diastolic_bp,
            temperature=temperature,
            weight=weight,
            respiratory_rate=respiratory_rate,
            heart_rate=heart_rate,
            bmi=bmi,
            blood_sugar_f=blood_sugar_f,
            blood_sugar_r=blood_sugar_r,
            spo2=spo2
        )
        new.save()

    return render(request,'AddPatient.html')
def AllPatient(request):
    if request.method == 'POST':
        if  request.POST.get('title') and request.POST.get('name') and request.POST.get('gender') and request.POST.get('date_of_birth') and request.POST.get('age') and request.POST.get('address') and request.POST.get('contact_no'):
            obj1=AddP()
            obj1.title=request.POST.get('title')
            obj1.name=request.POST.get('name')
            obj1.gender=request.POST.get('gender')
            obj1.date_of_birth=request.POST.get('date_of_birth')
            obj1.age=request.POST.get('age')
            obj1.address=request.POST.get('address')
            obj1.contact_no=request.POST.get('contact_no')
            obj1.save()
            info=AddP.object.all()
            return render(request,'AllPatient',{'obj1':info})
    else:
        info=AddP.objects.all()
        return render(request,'AllPatient.html',{'obj1':info})
    return render(request,'AllPatient.html',{"data":obj1})
def delete(request,myid1):
    obj1=AddP.objects.get(id=myid1)
    obj1.delete()
    # messages.info(request,"")
    return redirect(AllPatient)

    
def EditPatient(request):
    return render(request,'EditPatient.html')



#-----------------------------------DOCTOR------------------------------------------------------------
def AddDoctor(request):
    if request.method == 'POST':
    # Get the form data submitted by the user
       
        name = request.POST.get('name')
        Email = request.POST.get('Email')
        Phone = request.POST.get('Phone')
        date_of_birth = request.POST.get('date_of_birth')
        gender = request.POST.get('gender')
        password = request.POST.get('password')
        
        confirm_password = request.POST.get('confirm_password')
        Designation = request.POST.get('Designation')
        Degree = request.POST.get('Degree')
        department = request.POST.get('department')
        speciality = request.POST.get('speciality')
        experience = request.POST.get('experience')
        service_place = request.POST.get('service_place')
        address = request.POST.get('address')
        # profile_picture = request.POST.get('profile_picture')
        

        # Save the form data to the database using the HealthRecord model
        new1 = AddDoctor(
            # title=title,
            name = name,
            Email = Email,
            Phone = Phone,
            date_of_birth = date_of_birth,
            gender = gender,
            password = password,
            confirm_password = confirm_password,
            Designation = Designation,
            Degree = Degree,
            department = department,
            speciality = speciality,
            experience = experience,
            service_place = service_place,
            address = address,
            # profile_picture = profile_picture,
          )
        new1.save()

       
    # return render(request,'AddPatient.html',{})
    # return redirect()
    # return HttpResponse("DOCTOR ADDED")
    return render(request,'AddDoctor.html')
def AllDoctor(request):
    if request.method == 'POST':
        if request.POST.get('name')and request.POST.get('Email')and request.POST.get('Phone')and request.POST.get('date_of_birth')and request.POST.get('gender')and request.POST.get('Destination')and request.POST.get('Degree'):
            obj2=AddDoctor()
            obj2.name=request.POST.get('name')
            obj2.Email=request.POST.get('Email')
            obj2.Phone=request.POST.get('Phone')
            obj2.date_of_birth=request.POST.get('date_of_birth')
            obj2.gender=request.POST.get('gender')
            
            obj2.Designation=request.POST.get('Designation')
            obj2.Degree=request.POST.get('Degree')
            # obj1.contact_no=request.POST.get('contact_no')
            obj2.save()
            info=AddDoctor.object.all()
            return render(request,'AllDoctor',{'obj2':info})
    else:
        info=AddDoctor.objects.all()
        return render(request,'AllDoctor.html',{'obj2':info})
    return render(request,'AllDoctor.html',{"data":obj2})
def delete_Dr(request,Myid):
    obj2=AddDoctor.objects.get(id=Myid)
    obj2.delete()
    return redirect(AllDoctor)

# def edit_Dr(request, Myid):
#     edit_obj2=AddDoc.objects.get(id=Myid)
#     info=AddDoc.objects.all()
#     context = {
#         'edit_obj2': edit_obj2 ,
#         'info':info
#     }
#     return render(request , 'AllDoctor', context)
    
def EditDoctor(request):
    # obj2=AddDoc.objects.get(id=id)
    return render(request,'EditDoctor.html')



#----------------------------------Appointment---------------------------------------------

def AddAppointment(request):
    if request.method == 'POST':
        name = request.POST.get('name')
        date = request.POST.get('date')
        start_time = request.POST.get('start_time')
        end_time = request.POST.get('end_time')
        address = request.POST.get('creditcard')
        birth_date = request.POST.get('birth_date')
        mobile_number = request.POST.get('mobile_number')
        email = request.POST.get('email')
        consulting_doctor = request.POST.get('consulting_doctor')
        injury_condition = request.POST.get('injury_condition')
        therapy_started_date = request.POST.get('therapy_started_date')
        note = request.POST.get('address')

        new2 = Appointment(
            name=name,
            date=date,
            start_time=start_time,
            end_time=end_time,
            address=address,
            birth_date=birth_date,
            mobile_number=mobile_number,
            email=email,
            consulting_doctor=consulting_doctor,
            injury_condition=injury_condition,
            therapy_started_date=therapy_started_date,
            note=note,
        )
        new2.save()
    return render(request,'AddAppointment.html')


def AllAppointment(request):
    if request.method == 'POST':
        if request.POST.get('name')and request.POST.get('date')and request.POST.get('start_time')and request.POST.get('end_time')and request.POST.get('address')and request.POST.get('birth_date')and request.POST.get('mobile_number')and request.POST.get('consulting_doctor'):
            obj3=Appointment()
            obj3.name=request.POST.get('name')
            obj3.date=request.POST.get('date')
            obj3.start_time=request.POST.get('start_time')
            obj3.end_time=request.POST.get('end_time')
            obj3.address=request.POST.get('address')
            obj3.birth_date=request.POST.get('birth_date')
            obj3.mobile_number=request.POST.get('mobile_number')
            obj3.consulting_doctor=request.POST.get('consulting_doctor')
            # obj1.contact_no=request.POST.get('contact_no')
            obj3.save()
            info=Appointment.object.all()
            return render(request,'AllAppointment',{'obj3':info})
    else:
        info=Appointment.objects.all()
        return render(request,'AllAppointment.html',{'obj3':info})
    return render(request,'AllAppointment.html',{"data":obj3})
def delete_App(request,Myid2):
    obj3=Appointment.objects.get(id=Myid2)
    obj3.delete()
    return redirect(AllAppointment)
    
def EditAppointment(request):
    return render(request, 'EditAppointment.html')



#-------------------------------------------PAYMENT--------------------------------------
def AddPayment(request):
    if request.method == 'POST':
        transaction_id = request.POST.get('transaction_id')
        patient_name = request.POST.get('patient_name')
        doctor_name = request.POST.get('doctor_name')
        payment_date = request.POST.get('payment_date')
        total_amount = request.POST.get('total_amount')
        payment_method = request.POST.get('payment_method')
        payment_status = request.POST.get('payment_status')
        payment= Payment(
        transaction_id= transaction_id,
        patient_name= patient_name,
        doctor_name= doctor_name,
        payment_date= payment_date,
        total_amount= total_amount,
        
        payment_method= payment_method,
        payment_status= payment_status,
        )
        payment.save()

    return render(request,'AddPayment.html')
def AllPayment(request):
    if request.method == 'POST':
        if request.POST.get('transaction_id') and request.POST.get('patient_name') and request.POST.get('doctor_name') and request.POST.get('payment_date') and request.POST.get('total_amount') and request.POST.get('payment_method') and request.POST.get('payment_status'):
            obj=Payment()
            obj.transaction_id=request.POST.get('transaction_id')
            obj.patient_name=request.POST.get('patient_name')
            obj.doctor_name=request.POST.get('doctor_name')
            obj.payment_date=request.POST.get('payment_date')
            obj.total_amount=request.POST.get('total_amount')
            obj.payment_status=request.POST.get('payment_status')
            obj.save()
            info=Payment.object.all()
            return render(request,'AllPayment',{'obj':info})
   
    else:
        info=Payment.objects.all()
        return render(request,'AllPayment.html',{'obj':info})
    return render(request,'AllPayment.html',{"data":obj})
def delete_item(request,myid):
    obj=Payment.objects.get(id=myid)
    obj.delete()
    # messages.info(request,"")
    return redirect(AllPayment)
def Invoice(request):
    return render(request,'Invoice.html')
def navbar(request):
    obj=Payment.objects.all()
    
    return render(request,'navbar.html',{'obj':obj})

def login(request):
    return render(request,'login.html')
def signup(request):
    return render(request,'signup.html')

