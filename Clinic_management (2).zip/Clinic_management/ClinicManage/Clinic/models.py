from django.db import models

# Create your models here.

class Log_in_id(models. Model):
    Username = models.CharField(max_length=50)
    Password = models.CharField(max_length=50)
    def __str__(self):
        return self.username
    

class AddP(models.Model):
    title = models.CharField(max_length=255)
    name = models.CharField(max_length=255, null=True, blank=True)
    gender = models.CharField(max_length=10)
    date_of_birth = models.DateField(null=True, blank=True)
    age = models.IntegerField(null=True, blank=True)
    address = models.TextField(null=True, blank=True)
    contact_no = models.CharField(max_length=20, null=True, blank=True)
    blood_group = models.CharField(max_length=10, null=True, blank=True)
    systolic_bp = models.CharField(max_length=10, null=True, blank=True)
    diastolic_bp = models.CharField(max_length=10, null=True, blank=True)
    temperature = models.CharField(max_length=10, null=True, blank=True)
    weight = models.CharField(max_length=10, null=True, blank=True)
    respiratory_rate = models.CharField(max_length=10, null=True, blank=True)
    heart_rate = models.CharField(max_length=10, null=True, blank=True)
    bmi = models.CharField(max_length=10, null=True, blank=True)
    blood_sugar_f = models.CharField(max_length=10, null=True, blank=True)
    blood_sugar_r = models.CharField(max_length=10, null=True, blank=True)
    spo2 = models.CharField(max_length=10, null=True, blank=True)

    def __str__(self):
        return self.name
    
# from django.db import models

class AddDoctor(models.Model):
    name = models.CharField(max_length=100)
    Email = models.EmailField()
    Phone = models.CharField(max_length=15, blank=True, null=True)
    date_of_birth = models.DateField(blank=True, null=True)
    gender = models.CharField(max_length=10,blank=True, null=True)
    password = models.CharField(max_length=100)
    confirm_password = models.CharField(max_length=100)
    Designation = models.CharField(max_length=100, blank=True, null=True)
    Degree = models.CharField(max_length=100, blank=True, null=True)
    department = models.CharField(max_length=100, blank=True, null=True)
    speciality = models.CharField(max_length=100, blank=True, null=True)
    experience = models.CharField(max_length=100, blank=True, null=True)
    service_place = models.CharField(max_length=100, blank=True, null=True)
    address = models.TextField(blank=True, null=True)
    # profile_picture = models.ImageField(upload_to='photos/', blank=True, null=True)
    def __str__(self):
        return self.name


class Appointment(models.Model):
    name = models.CharField(max_length=100,null=True)
    date = models.DateField()
    start_time = models.TimeField()
    end_time = models.TimeField()
    address = models.CharField(max_length=200, blank=True, null=True)
    birth_date = models.DateField()
    mobile_number = models.CharField(max_length=12, null=True, blank=True)
    email = models.EmailField(blank=True, null=True)
    consulting_doctor = models.CharField(max_length=100,null=True)
    injury_condition = models.CharField(max_length=200, blank=True, null=True)
    therapy_started_date = models.DateField()
    note = models.TextField(blank=True, null=True)

    def __str__(self):
        return self.name



class Payment(models.Model):
    
    payment_status = models.CharField(max_length=244, null=True)
    payment_method = models.CharField(max_length=200, null=True)
    transaction_id = models.CharField(max_length=100)
    patient_name = models.CharField(max_length=100)
    doctor_name = models.CharField(max_length=100)
    payment_date = models.DateField(null=True, blank=True)
    total_amount = models.DecimalField(max_digits=10, decimal_places=2)  
    



    

    # payment_method = models.CharField(max_length=20, choices=TRANSACTION_CHOICES, default='Cash')
    # payment_status = models.CharField(max_length=20, choices=PAYMENT_STATUS_CHOICES, default='Pending')

    def __str__(self):
        return self.patient_name
    

    
    
        
    
