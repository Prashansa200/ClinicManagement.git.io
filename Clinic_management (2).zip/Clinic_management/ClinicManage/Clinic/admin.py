from django.contrib import admin

# Register your models here.
from .models import AddP,AddDoctor,Payment,Appointment, Log_in_id
admin.site.register(AddP)

admin.site.register(AddDoctor)
admin.site.register(Appointment)
admin.site.register(Payment)
admin.site.register(Log_in_id)