from django.contrib import admin
from django.urls import path, include
# from django.urls import path
from . import views 
from django.urls.conf import include
from django.contrib.staticfiles.urls import staticfiles_urlpatterns

urlpatterns = [
    
    # path('', about, name='about'),
    path('Dashboard',views.Dashboard,name='Dashboard'),
    path('AllPatient/', views.AllPatient, name='AllPatient'),
    path('AddPatient/', views.AddPatient, name='AddPatient'),
    path('EditPatient', views.EditPatient, name='EditPatient'),
    path('AllDoctor/', views.AllDoctor, name='AllDoctor'),
    path('AddDoctor/', views.AddDoctor, name='AddDoctor'),
    path('EditDoctor/', views.EditDoctor, name='EditDoctor'),
    path('AllAppointment', views.AllAppointment, name='AllAppointment'),
    path('AddAppointment/', views.AddAppointment, name='AddAppointment'),
    path('EditAppointment', views.EditAppointment, name='EditAppointment'),
    path('AddPayment/', views.AddPayment, name='AddPayment'),
    path('AllPayment/', views.AllPayment, name='AllPayment'),
    path('', views.Loginpage, name='Loginpage'),
    
    # path('signup/', views.signup, name='signup'),
    path('Invoice/', views.Invoice, name='Invoice'),
    path('delete_item/<int:myid>/', views.delete_item, name='delete_item'),
    path('delete/<int:myid1>/', views.delete, name='delete'),
    path('delete_Dr/<int:Myid>/', views.delete_Dr, name='delete_Dr'),
    path('delete_App/<int:Myid2>/', views.delete_App, name='delete_App'),
    # path('edit_payment/<int:payment_id>/', views.edit_payment, name='edit_payment'),
    # path('edit_Dr/<int:Myid>/', views.edit_Dr, name='edit_Dr'),
   
]